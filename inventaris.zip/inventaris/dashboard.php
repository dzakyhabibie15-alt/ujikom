<?php
require_once 'config/koneksi.php';
require_once 'includes/auth.php';
require_once 'includes/crud.php';
require_once 'includes/hitung.php';

wajibLogin();

$semua = semuaBarang($db);
$r = ringkasan($semua);
$terbaru = array_slice($semua, 0, 5);

$judul = 'Dashboard';
require 'includes/header.php';
?>
<div class="row g-3 mb-4">
    <div class="col-12 col-md-4">
        <div class="kartu">
            <div class="label">Jumlah barang</div>
            <div class="angka"><?= e(number_format($r['jumlah'], 0, ',', '.')) ?></div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="kartu">
            <div class="label">Total stok</div>
            <div class="angka"><?= e(number_format($r['stok'], 0, ',', '.')) ?></div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="kartu">
            <div class="label">Total nilai</div>
            <div class="angka"><?= e(rupiah($r['nilai'])) ?></div>
        </div>
    </div>
</div>

<div class="panel">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="fs-5 mb-0">Barang terbaru</h2>
        <a href="barang_form.php" class="btn btn-sm btn-primary">Tambah barang</a>
    </div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead>
                <tr><th>Kode</th><th>Nama</th><th>Kategori</th><th class="text-end">Stok</th></tr>
            </thead>
            <tbody>
            <?php if (!$terbaru): ?>
                <tr><td colspan="4" class="text-center text-muted py-3">Belum ada data barang.</td></tr>
            <?php endif; ?>
            <?php foreach ($terbaru as $b): ?>
                <tr>
                    <td><?= e($b['kode']) ?></td>
                    <td><?= e($b['nama']) ?></td>
                    <td><?= e($b['kategori']) ?></td>
                    <td class="text-end"><?= e($b['stok']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require 'includes/footer.php'; ?>
