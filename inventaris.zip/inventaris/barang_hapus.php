<?php
require_once 'config/koneksi.php';
require_once 'includes/auth.php';
require_once 'includes/validasi.php';
require_once 'includes/crud.php';

wajibLogin();

// Hapus hanya lewat POST + CSRF, lalu redirect ke daftar
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('barang.php');
}

if (!csrfValid()) {
    setFlash('error', 'Sesi formulir tidak valid. Coba lagi.');
    redirect('barang.php');
}

$id = validasiId($_POST['id'] ?? null);
if ($id === null) {
    setFlash('error', 'ID barang tidak valid.');
    redirect('barang.php');
}

if (hapusBarang($db, $id)) {
    setFlash('sukses', 'Barang berhasil dihapus.');
} else {
    setFlash('error', 'Barang tidak ditemukan atau sudah dihapus.');
}
redirect('barang.php');
