<?php
require_once 'config/koneksi.php';
require_once 'includes/auth.php';
require_once 'includes/crud.php';
require_once 'includes/hitung.php';

wajibLogin();

$fpdf = __DIR__ . '/lib/fpdf/fpdf.php';
if (!is_file($fpdf)) {
    setFlash('error', 'Library FPDF belum dipasang di folder lib/fpdf.');
    redirect('laporan.php');
}
require_once $fpdf;

// FPDF memakai encoding Latin-1, jadi teks UTF-8 dikonversi dulu
function teksPdf(string $t): string
{
    $hasil = @iconv('UTF-8', 'windows-1252//TRANSLIT//IGNORE', $t);
    return $hasil === false ? '' : $hasil;
}

function potong(string $t, int $maks): string
{
    return mb_strimwidth($t, 0, $maks, '...', 'UTF-8');
}

class LaporanPDF extends FPDF
{
    public $lebar = [10, 22, 50, 30, 28, 14, 36]; // total 190 mm

    function Header()
    {
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 8, 'Laporan Data Barang', 0, 1, 'C');
        $this->SetFont('Arial', '', 9);
        $this->Cell(0, 5, 'Dicetak: ' . date('d-m-Y H:i'), 0, 1, 'C');
        $this->Ln(4);

        $this->SetFont('Arial', 'B', 9);
        $this->SetFillColor(29, 79, 122);
        $this->SetTextColor(255);
        foreach (['No', 'Kode', 'Nama', 'Kategori', 'Harga', 'Stok', 'Nilai'] as $i => $judul) {
            $this->Cell($this->lebar[$i], 7, $judul, 1, 0, 'C', true);
        }
        $this->Ln();
        $this->SetTextColor(0);
        $this->SetFont('Arial', '', 9);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Halaman ' . $this->PageNo() . ' dari {nb}', 0, 0, 'C');
    }
}

$daftar = semuaBarang($db);
$r = ringkasan($daftar);

$pdf = new LaporanPDF('P', 'mm', 'A4');
$pdf->AliasNbPages();
$pdf->AddPage();
$lebar = $pdf->lebar;

if (!$daftar) {
    $pdf->Cell(array_sum($lebar), 8, 'Belum ada data barang.', 1, 1, 'C');
}

foreach ($daftar as $i => $b) {
    $harga = (int) $b['harga'];
    $stok = (int) $b['stok'];
    $pdf->Cell($lebar[0], 6, $i + 1, 1, 0, 'C');
    $pdf->Cell($lebar[1], 6, teksPdf(potong($b['kode'], 11)), 1);
    $pdf->Cell($lebar[2], 6, teksPdf(potong($b['nama'], 26)), 1);
    $pdf->Cell($lebar[3], 6, teksPdf(potong($b['kategori'], 15)), 1);
    $pdf->Cell($lebar[4], 6, rupiah($harga), 1, 0, 'R');
    $pdf->Cell($lebar[5], 6, $stok, 1, 0, 'R');
    $pdf->Cell($lebar[6], 6, rupiah($harga * $stok), 1, 1, 'R');
}

$pdf->SetFont('Arial', 'B', 9);
$pdf->Cell(array_sum(array_slice($lebar, 0, 5)), 7, 'Total (' . $r['jumlah'] . ' jenis barang)', 1, 0, 'R');
$pdf->Cell($lebar[5], 7, $r['stok'], 1, 0, 'R');
$pdf->Cell($lebar[6], 7, rupiah($r['nilai']), 1, 1, 'R');

$pdf->Output('I', 'laporan-barang.pdf');
