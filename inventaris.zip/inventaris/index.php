<?php
require_once 'includes/auth.php';
redirect(sudahLogin() ? 'dashboard.php' : 'login.php');
