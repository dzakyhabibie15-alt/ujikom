# Tutorial: CRUD Data Barang (PHP Native + MySQL)

## 1. Cara menjalankan di XAMPP

1. Nyalakan **Apache** dan **MySQL** di XAMPP Control Panel.
2. Salin folder `inventaris` ke `C:\xampp\htdocs\`.
3. Buka `http://localhost/phpmyadmin`, pilih tab **Import**, pilih file `database.sql`, klik **Import**.
4. Buka `http://localhost/inventaris/`. Klik **Registrasi** untuk membuat akun, lalu login.

Library FPDF sudah ada di `lib/fpdf/`. Bila hilang, unduh dari fpdf.org dan taruh `fpdf.php` + folder `font` di sana.
Bila password MySQL Anda tidak kosong, ubah di `config/koneksi.php`.

## 2. Struktur folder

```
inventaris/
  config/koneksi.php      koneksi database
  includes/
    helper.php            e(), redirect(), input(), flash message
    auth.php              session, proteksi halaman, CSRF
    validasi.php          fungsi validasi
    crud.php              semua query database (prepared statement)
    hitung.php            hitung total + format rupiah
    header.php            doctype, navbar, judul halaman
    footer.php            footer + script Bootstrap
  assets/css/style.css    CSS kustom (1 warna utama)
  assets/js/app.js        isi data ke modal hapus
  lib/fpdf/               library FPDF
  register.php  login.php  logout.php  index.php
  dashboard.php           ringkasan: jumlah, total stok, total nilai
  barang.php              tabel + cari + tombol edit/hapus
  barang_form.php         form tambah DAN edit (satu file)
  barang_hapus.php        proses hapus (POST saja)
  laporan.php             tabel laporan
  laporan_pdf.php         cetak PDF dengan FPDF
  database.sql
```

Prinsip yang dipakai: **halaman (`*.php` di root) hanya mengatur alur**, sedangkan logika ada di `includes/`.
Sehingga kode pendek dan mudah dijelaskan saat uji kompetensi.

## 3. Alur umum satu halaman

Hampir semua halaman punya urutan yang sama:

```
1. require file yang dibutuhkan
2. wajibLogin()                  -> cek session
3. proses POST (bila ada)        -> cek CSRF -> validasi -> simpan -> redirect
4. ambil data untuk ditampilkan
5. $judul = '...'; require header.php
6. HTML
7. require footer.php
```

Bagian 1-4 **harus** sebelum ada output HTML, karena `header('Location: ...')` tidak bisa dipakai
setelah ada output. Itu sebabnya `header.php` baru di-include di bagian 5.

## 4. Penjelasan kode per file

### database.sql
- `users`: `username` dibuat `UNIQUE`, `password` `VARCHAR(255)` karena hasil `password_hash` panjang.
- `barang`: `kode` `UNIQUE` supaya tidak ada kode ganda sekalipun validasi PHP terlewat.
  `harga` dan `stok` bertipe `UNSIGNED` sehingga tidak bisa negatif.

### config/koneksi.php
- `mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT)` membuat error MySQL menjadi **exception**
  (`mysqli_sql_exception`), jadi bisa ditangkap dengan `try/catch`.
- `set_charset('utf8mb4')` agar karakter non-Latin aman.
- Bila gagal konek, tampilkan pesan umum, bukan detail error (detail bisa membocorkan informasi).

### includes/helper.php
- `e()` = `htmlspecialchars(..., ENT_QUOTES, 'UTF-8')`. **Semua** data dari user/DB yang dicetak ke HTML
  dibungkus `e()`. Inilah perlindungan dari XSS. Uji: isi nama barang `<b>tes</b>`, tampil sebagai teks biasa.
- `redirect()` = `header('Location')` + `exit`. `exit` penting agar kode setelahnya tidak jalan.
- `input()` mengambil `$_POST[...]` sebagai string. Jika yang dikirim array (`nama[]=x`), hasilnya `''`,
  sehingga tidak error. Parameter `$trim=false` dipakai untuk password agar spasi tidak terpotong.
- `setFlash()` / `ambilFlash()` menyimpan pesan sekali tampil di session (dipakai setelah redirect).

### includes/auth.php
- `session_start()` dengan cookie `httponly` (tidak bisa dibaca JavaScript) dan `samesite=Lax`.
- `wajibLogin()` dipanggil di awal setiap halaman terproteksi. Tidak ada `$_SESSION['user_id']` -> redirect ke login.
- `loginUser()` memanggil `session_regenerate_id(true)` untuk mencegah *session fixation*.
- `logoutUser()` mengosongkan `$_SESSION`, menghapus cookie, dan `session_destroy()`.
- **CSRF**: `csrfToken()` membuat token acak (`random_bytes`) sekali per session. `csrfField()` mencetaknya
  sebagai input tersembunyi di setiap form POST. `csrfValid()` membandingkan token kiriman dengan token session
  memakai `hash_equals()` (perbandingan aman). Tanpa token yang benar, request POST ditolak.

### includes/validasi.php
Fungsi **tidak menyentuh database** dan hanya mengembalikan array error (`['kode' => 'pesan', ...]`).
Kosong berarti valid.
- Nomor/angka dicek dengan `ctype_digit()`: hanya digit 0-9, sehingga `-5`, `abc`, `1.5`, dan string kosong ditolak.
- Batas panjang (`strlen <= 12`) mencegah angka terlalu besar.
- `validasiId()` mengembalikan `int` atau `null`. Dipakai untuk `?id=...` dari URL: `abc`, `0`, `-1`, dan `1;DROP` ditolak.

### includes/crud.php
Semua query memakai **prepared statement**:
```php
$st = $db->prepare('SELECT * FROM barang WHERE id = ?');
$st->bind_param('i', $id);   // i = integer, s = string
$st->execute();
```
Nilai user **tidak pernah digabung** ke string SQL, jadi SQL injection tidak mungkin.
- `kodeSudahAda($db, $kode, $kecualiId)`: saat edit, barang itu sendiri dikecualikan (`id <> ?`),
  sehingga menyimpan tanpa mengubah kode tidak dianggap duplikat.
- `hapusBarang()` mengembalikan `true/false` dari `affected_rows`, jadi kita tahu apakah ID benar-benar ada.

### includes/hitung.php
- `ringkasan()` melooping data: jumlah jenis barang, total stok, total nilai (`harga x stok` tiap barang dijumlahkan).
- `rupiah()` memformat angka: `number_format(2500, 0, ',', '.')` -> `Rp 2.500`.

### includes/header.php dan footer.php
- Satu layout dipakai semua halaman, sehingga tampilan konsisten: navbar, judul halaman, konten (`<main>`), footer.
- `d-flex flex-column min-vh-100` pada `<body>` + `flex-grow-1` pada `<main>` membuat footer selalu di bawah.
- Navbar Bootstrap (`navbar-expand-md`) otomatis menjadi menu lipat di layar HP.
- Logout memakai **form POST + CSRF**, bukan link biasa, agar tidak bisa dipicu dari situs lain.
- Menu hanya muncul bila `sudahLogin()`.

### register.php
1. Jika sudah login -> ke dashboard.
2. Saat POST: cek CSRF -> `validasiRegistrasi()` -> cek username sudah ada -> `password_hash()` -> simpan.
3. Berhasil -> `setFlash` + `redirect('login.php')` (**POST-redirect-GET**: refresh browser tidak mengirim ulang form).
4. `try/catch` kode error **1062** menangani kasus langka dua orang mendaftar username yang sama bersamaan.
5. Nilai yang sudah diketik dikembalikan ke form (`value="<?= e($nama) ?>"`), password tidak.

### login.php
- `password_verify($passwordInput, $hashDiDB)` membandingkan password dengan hash.
- Pesan error dibuat **sama** untuk username salah maupun password salah ("Username atau password salah"),
  agar penyerang tidak bisa menebak username mana yang terdaftar.

### logout.php
Hanya berlaku bila POST dan CSRF valid. Setelah session dihancurkan, session baru dibuka lagi hanya untuk pesan "Anda sudah logout".

### dashboard.php
Memanggil `semuaBarang()` -> `ringkasan()` -> tampil dalam 3 kartu. `array_slice($semua, 0, 5)` mengambil 5 barang terbaru.

### barang.php
- Pencarian memakai `GET ?q=...` dengan `LIKE ?` pada kode, nama, dan kategori (tetap prepared statement; tanda `%` ditambahkan di PHP).
- Tabel dibungkus `table-responsive` agar bisa digeser di HP.
- **Konfirmasi hapus**: tombol Hapus membuka modal Bootstrap. `assets/js/app.js` mengisi ID dan nama barang ke modal.
  Form di modal mengirim POST ke `barang_hapus.php`.

### barang_form.php (tambah + edit dalam satu file)
- Ada `id` (dari `?id=` saat dibuka, dari input tersembunyi saat disimpan) -> mode **edit**. Tidak ada -> mode **tambah**.
- ID dicek `validasiId()` lalu `barangById()`. ID tidak valid atau tidak ditemukan -> pesan error + redirect ke daftar.
- Saat disimpan: CSRF -> `validasiBarang()` -> `kodeSudahAda()` -> `tambahBarang()` atau `ubahBarang()` -> redirect.
- Jika ada error, form tampil lagi dengan isian lama dan pesan di bawah kolom (`is-invalid` dari Bootstrap).

### barang_hapus.php
Hanya POST. Urutan: CSRF -> `validasiId()` -> `hapusBarang()` -> flash -> redirect. Membuka URL ini lewat GET hanya redirect, tidak menghapus apa pun.

### laporan.php dan laporan_pdf.php
- `laporan.php` menampilkan tabel + baris total, dengan tombol **Cetak PDF**.
- `laporan_pdf.php` membuat class `LaporanPDF extends FPDF`. Method `Header()` dan `Footer()` otomatis dijalankan di tiap halaman
  (judul, header tabel, nomor halaman `{nb}` = total halaman).
- FPDF memakai encoding Latin-1, maka teks dikonversi dengan `iconv` (fungsi `teksPdf`). Nama panjang dipotong dengan `mb_strimwidth`
  agar tidak keluar dari kolom.
- Tidak boleh ada output apa pun sebelum `$pdf->Output()`. Karena itu file di `includes/` tidak memakai tag penutup `?>` di akhir
  dan tidak ada spasi di luar tag PHP.
- Properti `$lebar` sengaja tidak bernama `$w`, karena `$w` sudah dipakai FPDF untuk lebar halaman.

### assets/css/style.css
Satu warna utama (`#1d4f7a`) disimpan di variabel `--warna-utama`, sisanya abu-abu netral.
Variabel Bootstrap `--bs-primary` ditimpa agar tombol dan link ikut warna ini. Tanpa gradasi, tanpa ikon dekoratif.

## 5. Checklist uji (sama dengan yang saya jalankan)

| Uji | Hasil yang benar |
|---|---|
| Buka `dashboard.php` / `barang.php` / `laporan.php` tanpa login | Diarahkan ke login |
| Registrasi dengan field kosong, password pendek, konfirmasi beda | Pesan error per kolom |
| Registrasi username yang sama (huruf besar/kecil beda) | "Username sudah dipakai" |
| Cek kolom `password` di phpMyAdmin | Diawali `$2y$` (hash), bukan teks asli |
| Login salah / benar | Pesan error / masuk dashboard |
| Tambah barang dengan kolom kosong, harga `-5`, stok `abc` | Pesan error per kolom |
| Tambah dengan kode yang sudah ada | "Kode barang sudah dipakai" |
| Nama barang `<b>tes</b>` | Tampil sebagai teks, tidak menjadi tebal |
| Cari "buku" | Hanya barang yang cocok |
| `barang_form.php?id=abc`, `id=0`, `id=999` | Pesan error, kembali ke daftar |
| Edit lalu simpan tanpa ubah kode | Berhasil (tidak dianggap duplikat) |
| Edit dengan kode milik barang lain | "Kode barang sudah dipakai" |
| Hapus | Muncul konfirmasi, lalu data hilang |
| Refresh (F5) setelah simpan/hapus | Tidak mengirim ulang data |
| Dashboard: jumlah, total stok, total nilai | Sesuai hitungan manual |
| Cetak PDF | PDF terbuka, isi sama dengan laporan |
| Logout lalu klik Back / buka `dashboard.php` | Diarahkan ke login |
| Perkecil jendela / buka di HP | Menu jadi lipat, tabel bisa digeser |

## 6. Masalah yang sering muncul

- **"Koneksi database gagal"**: MySQL belum aktif, atau `database.sql` belum diimpor.
- **Halaman putih / error `mb_strlen` atau `iconv`**: aktifkan `extension=mbstring` dan `extension=iconv` di `php.ini` (XAMPP biasanya sudah aktif).
- **"Cannot modify header information"**: ada output (spasi, `echo`) sebelum `redirect()`. Pastikan logika sebelum `require 'includes/header.php'`.
- **PDF rusak / "Some data has already been output"**: ada spasi atau teks sebelum `<?php` di file yang di-include.
- **Tampilan tanpa Bootstrap**: perangkat tidak terhubung internet (Bootstrap dimuat dari CDN).

## 7. Bahan latihan agar paham, bukan sekadar menyalin

1. Tambahkan kolom `satuan` pada barang (ubah SQL, validasi, `crud.php`, form, tabel).
2. Tambahkan pagination 10 data per halaman di `barang.php` (`LIMIT ? OFFSET ?`).
3. Tambahkan filter kategori pada pencarian.
