<?php
// Header + navbar. Set $judul sebelum meng-include file ini.
require_once __DIR__ . '/auth.php';

$halaman = basename($_SERVER['SCRIPT_NAME']);
$flash = ambilFlash();

function navAktif(array $files, string $halaman): string
{
    return in_array($halaman, $files, true) ? ' active' : '';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($judul ?? 'Halaman') ?> - Inventaris Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">

<nav class="navbar navbar-expand-md navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="<?= sudahLogin() ? 'dashboard.php' : 'login.php' ?>">Inventaris Barang</a>
        <?php if (sudahLogin()): ?>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#menuUtama" aria-controls="menuUtama"
                    aria-expanded="false" aria-label="Buka menu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="menuUtama">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link<?= navAktif(['dashboard.php'], $halaman) ?>" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link<?= navAktif(['barang.php', 'barang_form.php'], $halaman) ?>" href="barang.php">Data Barang</a></li>
                    <li class="nav-item"><a class="nav-link<?= navAktif(['laporan.php'], $halaman) ?>" href="laporan.php">Laporan</a></li>
                </ul>
                <form method="post" action="logout.php" class="d-flex align-items-center gap-3 mt-2 mt-md-0">
                    <?= csrfField() ?>
                    <span class="navbar-text"><?= e($_SESSION['nama'] ?? '') ?></span>
                    <button type="submit" class="btn btn-sm btn-outline-light">Logout</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</nav>

<header class="page-header">
    <div class="container py-3">
        <h1><?= e($judul ?? '') ?></h1>
    </div>
</header>

<main class="container flex-grow-1 py-4">
<?php if ($flash): ?>
    <div class="pesan<?= $flash['tipe'] === 'error' ? ' pesan-error' : '' ?>" role="alert">
        <?= e($flash['pesan']) ?>
    </div>
<?php endif; ?>
