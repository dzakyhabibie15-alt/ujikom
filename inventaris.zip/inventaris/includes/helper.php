<?php
// Fungsi bantu umum

function e($teks): string
{
    return htmlspecialchars((string) $teks, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

// Ambil nilai POST sebagai string (array dianggap kosong)
function input(string $key, bool $trim = true): string
{
    $v = $_POST[$key] ?? '';
    if (!is_string($v)) {
        return '';
    }
    return $trim ? trim($v) : $v;
}

function setFlash(string $tipe, string $pesan): void
{
    $_SESSION['flash'] = ['tipe' => $tipe, 'pesan' => $pesan];
}

function ambilFlash(): ?array
{
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

function kelasError(array $err, string $k): string
{
    return isset($err[$k]) ? ' is-invalid' : '';
}

function pesanError(array $err, string $k): string
{
    return isset($err[$k]) ? '<div class="invalid-feedback">' . e($err[$k]) . '</div>' : '';
}
