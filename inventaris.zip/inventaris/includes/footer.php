</main>

<footer class="site-footer py-3 mt-auto">
    <div class="container text-center">
        Inventaris Barang &middot; <?= date('Y') ?>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
