<?php
// Semua query database. Selalu memakai prepared statement.

function cariUser(mysqli $db, string $username): ?array
{
    $st = $db->prepare('SELECT id, nama, username, password FROM users WHERE username = ?');
    $st->bind_param('s', $username);
    $st->execute();
    $row = $st->get_result()->fetch_assoc();
    $st->close();
    return $row ?: null;
}

function tambahUser(mysqli $db, string $nama, string $username, string $hash): void
{
    $st = $db->prepare('INSERT INTO users (nama, username, password) VALUES (?, ?, ?)');
    $st->bind_param('sss', $nama, $username, $hash);
    $st->execute();
    $st->close();
}

function semuaBarang(mysqli $db, string $cari = ''): array
{
    if ($cari !== '') {
        $like = '%' . $cari . '%';
        $st = $db->prepare('SELECT * FROM barang WHERE kode LIKE ? OR nama LIKE ? OR kategori LIKE ? ORDER BY id DESC');
        $st->bind_param('sss', $like, $like, $like);
    } else {
        $st = $db->prepare('SELECT * FROM barang ORDER BY id DESC');
    }
    $st->execute();
    $rows = $st->get_result()->fetch_all(MYSQLI_ASSOC);
    $st->close();
    return $rows;
}

function barangById(mysqli $db, int $id): ?array
{
    $st = $db->prepare('SELECT * FROM barang WHERE id = ?');
    $st->bind_param('i', $id);
    $st->execute();
    $row = $st->get_result()->fetch_assoc();
    $st->close();
    return $row ?: null;
}

// Cek kode sudah dipakai barang lain ($kecualiId dipakai saat edit)
function kodeSudahAda(mysqli $db, string $kode, int $kecualiId = 0): bool
{
    $st = $db->prepare('SELECT id FROM barang WHERE kode = ? AND id <> ? LIMIT 1');
    $st->bind_param('si', $kode, $kecualiId);
    $st->execute();
    $ada = $st->get_result()->num_rows > 0;
    $st->close();
    return $ada;
}

function tambahBarang(mysqli $db, array $d): void
{
    $st = $db->prepare('INSERT INTO barang (kode, nama, kategori, harga, stok) VALUES (?, ?, ?, ?, ?)');
    $harga = (int) $d['harga'];
    $stok = (int) $d['stok'];
    $st->bind_param('sssii', $d['kode'], $d['nama'], $d['kategori'], $harga, $stok);
    $st->execute();
    $st->close();
}

function ubahBarang(mysqli $db, int $id, array $d): void
{
    $st = $db->prepare('UPDATE barang SET kode = ?, nama = ?, kategori = ?, harga = ?, stok = ? WHERE id = ?');
    $harga = (int) $d['harga'];
    $stok = (int) $d['stok'];
    $st->bind_param('sssiii', $d['kode'], $d['nama'], $d['kategori'], $harga, $stok, $id);
    $st->execute();
    $st->close();
}

function hapusBarang(mysqli $db, int $id): bool
{
    $st = $db->prepare('DELETE FROM barang WHERE id = ?');
    $st->bind_param('i', $id);
    $st->execute();
    $terhapus = $st->affected_rows > 0;
    $st->close();
    return $terhapus;
}
