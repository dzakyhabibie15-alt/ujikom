<?php
// Fungsi perhitungan dan format angka

function ringkasan(array $barang): array
{
    $totalStok = 0;
    $totalNilai = 0;
    foreach ($barang as $b) {
        $totalStok += (int) $b['stok'];
        $totalNilai += (int) $b['harga'] * (int) $b['stok'];
    }
    return [
        'jumlah' => count($barang),
        'stok'   => $totalStok,
        'nilai'  => $totalNilai,
    ];
}

function rupiah(int $angka): string
{
    return 'Rp ' . number_format($angka, 0, ',', '.');
}
