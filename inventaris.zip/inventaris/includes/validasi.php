<?php
// Fungsi validasi input. Mengembalikan array pesan error (kosong = valid).

function validasiRegistrasi(array $d): array
{
    $err = [];
    if ($d['nama'] === '') {
        $err['nama'] = 'Nama wajib diisi.';
    } elseif (mb_strlen($d['nama']) > 100) {
        $err['nama'] = 'Nama maksimal 100 karakter.';
    }
    if (!preg_match('/^[A-Za-z0-9_]{4,30}$/', $d['username'])) {
        $err['username'] = 'Username 4-30 karakter: huruf, angka, atau garis bawah.';
    }
    if (strlen($d['password']) < 8) {
        $err['password'] = 'Password minimal 8 karakter.';
    }
    if ($d['password'] !== $d['password2']) {
        $err['password2'] = 'Konfirmasi password tidak cocok.';
    }
    return $err;
}

function validasiBarang(array $d): array
{
    $err = [];
    if (!preg_match('/^[A-Za-z0-9\-]{2,20}$/', $d['kode'])) {
        $err['kode'] = 'Kode 2-20 karakter: huruf, angka, atau tanda hubung.';
    }
    if ($d['nama'] === '') {
        $err['nama'] = 'Nama barang wajib diisi.';
    } elseif (mb_strlen($d['nama']) > 100) {
        $err['nama'] = 'Nama maksimal 100 karakter.';
    }
    if ($d['kategori'] === '') {
        $err['kategori'] = 'Kategori wajib diisi.';
    } elseif (mb_strlen($d['kategori']) > 50) {
        $err['kategori'] = 'Kategori maksimal 50 karakter.';
    }
    if (!ctype_digit($d['harga']) || strlen($d['harga']) > 12) {
        $err['harga'] = 'Harga harus angka bulat tidak negatif (maks. 12 digit).';
    }
    if (!ctype_digit($d['stok']) || strlen($d['stok']) > 9) {
        $err['stok'] = 'Stok harus angka bulat tidak negatif (maks. 9 digit).';
    }
    return $err;
}

// Mengembalikan ID sebagai int, atau null bila tidak valid
function validasiId($v): ?int
{
    if (is_string($v) && ctype_digit($v) && (int) $v > 0) {
        return (int) $v;
    }
    return null;
}
