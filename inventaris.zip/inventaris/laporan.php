<?php
require_once 'config/koneksi.php';
require_once 'includes/auth.php';
require_once 'includes/crud.php';
require_once 'includes/hitung.php';

wajibLogin();

$daftar = semuaBarang($db);
$r = ringkasan($daftar);

$judul = 'Laporan Barang';
require 'includes/header.php';
?>
<div class="panel">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <p class="mb-0 text-muted">Ringkasan seluruh data barang per <?= date('d-m-Y') ?>.</p>
        <a href="laporan_pdf.php" class="btn btn-primary" target="_blank" rel="noopener">Cetak PDF</a>
    </div>

    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead>
                <tr>
                    <th>No</th><th>Kode</th><th>Nama</th><th>Kategori</th>
                    <th class="text-end">Harga</th><th class="text-end">Stok</th><th class="text-end">Nilai</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$daftar): ?>
                <tr><td colspan="7" class="text-center text-muted py-3">Belum ada data barang.</td></tr>
            <?php endif; ?>
            <?php foreach ($daftar as $i => $b): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= e($b['kode']) ?></td>
                    <td><?= e($b['nama']) ?></td>
                    <td><?= e($b['kategori']) ?></td>
                    <td class="text-end"><?= e(rupiah((int) $b['harga'])) ?></td>
                    <td class="text-end"><?= e($b['stok']) ?></td>
                    <td class="text-end"><?= e(rupiah((int) $b['harga'] * (int) $b['stok'])) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="fw-semibold">
                    <td colspan="5" class="text-end">Total (<?= (int) $r['jumlah'] ?> jenis barang)</td>
                    <td class="text-end"><?= e(number_format($r['stok'], 0, ',', '.')) ?></td>
                    <td class="text-end"><?= e(rupiah($r['nilai'])) ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php require 'includes/footer.php'; ?>
