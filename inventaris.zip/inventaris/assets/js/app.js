// Isi data barang ke modal konfirmasi hapus
document.addEventListener('DOMContentLoaded', function () {
    var modal = document.getElementById('modalHapus');
    if (!modal) return;

    modal.addEventListener('show.bs.modal', function (ev) {
        var tombol = ev.relatedTarget;
        document.getElementById('hapusId').value = tombol.getAttribute('data-id');
        document.getElementById('hapusNama').textContent = tombol.getAttribute('data-nama');
    });
});
