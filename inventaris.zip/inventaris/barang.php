<?php
require_once 'config/koneksi.php';
require_once 'includes/auth.php';
require_once 'includes/crud.php';
require_once 'includes/hitung.php';

wajibLogin();

$cari = (isset($_GET['q']) && is_string($_GET['q'])) ? trim($_GET['q']) : '';
$daftar = semuaBarang($db, $cari);

$judul = 'Data Barang';
require 'includes/header.php';
?>
<div class="panel">
    <div class="row g-2 mb-3">
        <div class="col-12 col-md">
            <form method="get" class="d-flex gap-2">
                <input type="search" name="q" class="form-control" placeholder="Cari kode, nama, atau kategori" value="<?= e($cari) ?>" aria-label="Cari barang">
                <button type="submit" class="btn btn-outline-secondary">Cari</button>
                <?php if ($cari !== ''): ?>
                    <a href="barang.php" class="btn btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </form>
        </div>
        <div class="col-12 col-md-auto">
            <a href="barang_form.php" class="btn btn-primary w-100">Tambah barang</a>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>No</th><th>Kode</th><th>Nama</th><th>Kategori</th>
                    <th class="text-end">Harga</th><th class="text-end">Stok</th><th class="text-end">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$daftar): ?>
                <tr><td colspan="7" class="text-center text-muted py-3">Data tidak ditemukan.</td></tr>
            <?php endif; ?>
            <?php foreach ($daftar as $i => $b): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= e($b['kode']) ?></td>
                    <td><?= e($b['nama']) ?></td>
                    <td><?= e($b['kategori']) ?></td>
                    <td class="text-end"><?= e(rupiah((int) $b['harga'])) ?></td>
                    <td class="text-end"><?= e($b['stok']) ?></td>
                    <td class="text-end text-nowrap">
                        <a href="barang_form.php?id=<?= (int) $b['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                        <button type="button" class="btn btn-sm btn-outline-dark"
                                data-bs-toggle="modal" data-bs-target="#modalHapus"
                                data-id="<?= (int) $b['id'] ?>" data-nama="<?= e($b['nama']) ?>">Hapus</button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="modalHapus" tabindex="-1" aria-labelledby="judulHapus" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" action="barang_hapus.php" class="modal-content">
            <?= csrfField() ?>
            <input type="hidden" name="id" id="hapusId" value="">
            <div class="modal-header">
                <h2 class="modal-title fs-5" id="judulHapus">Konfirmasi hapus</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body">
                Hapus barang <strong id="hapusNama"></strong>? Data yang dihapus tidak dapat dikembalikan.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-dark">Hapus</button>
            </div>
        </form>
    </div>
</div>
<?php require 'includes/footer.php'; ?>
