<?php
require_once 'config/koneksi.php';
require_once 'includes/auth.php';
require_once 'includes/validasi.php';
require_once 'includes/crud.php';

wajibLogin();

$mode = 'tambah';
$id = 0;
$err = [];
$data = ['kode' => '', 'nama' => '', 'kategori' => '', 'harga' => '', 'stok' => ''];

// Mode edit bila ada id (dari link saat GET, dari input tersembunyi saat POST)
$idMentah = $_SERVER['REQUEST_METHOD'] === 'POST' ? ($_POST['id'] ?? null) : ($_GET['id'] ?? null);

if ($idMentah !== null && $idMentah !== '') {
    $id = validasiId($idMentah);
    if ($id === null) {
        setFlash('error', 'ID barang tidak valid.');
        redirect('barang.php');
    }
    $lama = barangById($db, $id);
    if (!$lama) {
        setFlash('error', 'Barang tidak ditemukan.');
        redirect('barang.php');
    }
    $mode = 'edit';
    $data = $lama;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'kode'     => input('kode'),
        'nama'     => input('nama'),
        'kategori' => input('kategori'),
        'harga'    => input('harga'),
        'stok'     => input('stok'),
    ];

    if (!csrfValid()) {
        $err['umum'] = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
    } else {
        $err = validasiBarang($data);

        if (!isset($err['kode']) && kodeSudahAda($db, $data['kode'], $id)) {
            $err['kode'] = 'Kode barang sudah dipakai.';
        }

        if (!$err) {
            try {
                if ($mode === 'edit') {
                    ubahBarang($db, $id, $data);
                    setFlash('sukses', 'Data barang berhasil diperbarui.');
                } else {
                    tambahBarang($db, $data);
                    setFlash('sukses', 'Barang baru berhasil ditambahkan.');
                }
                redirect('barang.php');
            } catch (mysqli_sql_exception $ex) {
                if ($ex->getCode() === 1062) {
                    $err['kode'] = 'Kode barang sudah dipakai.';
                } else {
                    $err['umum'] = 'Terjadi kesalahan saat menyimpan data.';
                }
            }
        }
    }
}

$judul = $mode === 'edit' ? 'Edit Barang' : 'Tambah Barang';
require 'includes/header.php';
?>
<div class="panel panel-form">
    <?php if (isset($err['umum'])): ?>
        <div class="pesan pesan-error"><?= e($err['umum']) ?></div>
    <?php endif; ?>
    <form method="post" novalidate>
        <?= csrfField() ?>
        <?php if ($mode === 'edit'): ?>
            <input type="hidden" name="id" value="<?= (int) $id ?>">
        <?php endif; ?>

        <div class="row g-3">
            <div class="col-12 col-md-4">
                <label for="kode" class="form-label">Kode</label>
                <input type="text" id="kode" name="kode" class="form-control<?= kelasError($err, 'kode') ?>" value="<?= e($data['kode']) ?>" maxlength="20" required>
                <?= pesanError($err, 'kode') ?>
            </div>
            <div class="col-12 col-md-8">
                <label for="nama" class="form-label">Nama barang</label>
                <input type="text" id="nama" name="nama" class="form-control<?= kelasError($err, 'nama') ?>" value="<?= e($data['nama']) ?>" maxlength="100" required>
                <?= pesanError($err, 'nama') ?>
            </div>
            <div class="col-12">
                <label for="kategori" class="form-label">Kategori</label>
                <input type="text" id="kategori" name="kategori" class="form-control<?= kelasError($err, 'kategori') ?>" value="<?= e($data['kategori']) ?>" maxlength="50" required>
                <?= pesanError($err, 'kategori') ?>
            </div>
            <div class="col-12 col-md-6">
                <label for="harga" class="form-label">Harga (Rp)</label>
                <input type="text" inputmode="numeric" id="harga" name="harga" class="form-control<?= kelasError($err, 'harga') ?>" value="<?= e($data['harga']) ?>" required>
                <?= pesanError($err, 'harga') ?>
            </div>
            <div class="col-12 col-md-6">
                <label for="stok" class="form-label">Stok</label>
                <input type="text" inputmode="numeric" id="stok" name="stok" class="form-control<?= kelasError($err, 'stok') ?>" value="<?= e($data['stok']) ?>" required>
                <?= pesanError($err, 'stok') ?>
            </div>
        </div>

        <div class="d-flex gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="barang.php" class="btn btn-outline-secondary">Batal</a>
        </div>
    </form>
</div>
<?php require 'includes/footer.php'; ?>
