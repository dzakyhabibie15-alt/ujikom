<?php
require_once 'config/koneksi.php';
require_once 'includes/auth.php';
require_once 'includes/validasi.php';
require_once 'includes/crud.php';

if (sudahLogin()) {
    redirect('dashboard.php');
}

$err = [];
$nama = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = input('nama');
    $username = input('username');
    $data = [
        'nama'      => $nama,
        'username'  => $username,
        'password'  => input('password', false),
        'password2' => input('password2', false),
    ];

    if (!csrfValid()) {
        $err['umum'] = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
    } else {
        $err = validasiRegistrasi($data);

        if (!$err && cariUser($db, $username)) {
            $err['username'] = 'Username sudah dipakai.';
        }

        if (!$err) {
            try {
                tambahUser($db, $nama, $username, password_hash($data['password'], PASSWORD_DEFAULT));
                setFlash('sukses', 'Registrasi berhasil. Silakan login.');
                redirect('login.php');
            } catch (mysqli_sql_exception $ex) {
                if ($ex->getCode() === 1062) {
                    $err['username'] = 'Username sudah dipakai.';
                } else {
                    $err['umum'] = 'Terjadi kesalahan saat menyimpan data.';
                }
            }
        }
    }
}

$judul = 'Registrasi';
require 'includes/header.php';
?>
<div class="panel panel-sempit">
    <?php if (isset($err['umum'])): ?>
        <div class="pesan pesan-error"><?= e($err['umum']) ?></div>
    <?php endif; ?>
    <form method="post" novalidate>
        <?= csrfField() ?>
        <div class="mb-3">
            <label for="nama" class="form-label">Nama lengkap</label>
            <input type="text" id="nama" name="nama" class="form-control<?= kelasError($err, 'nama') ?>" value="<?= e($nama) ?>" maxlength="100" required>
            <?= pesanError($err, 'nama') ?>
        </div>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" id="username" name="username" class="form-control<?= kelasError($err, 'username') ?>" value="<?= e($username) ?>" maxlength="30" autocomplete="username" required>
            <?= pesanError($err, 'username') ?>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" id="password" name="password" class="form-control<?= kelasError($err, 'password') ?>" autocomplete="new-password" required>
            <?= pesanError($err, 'password') ?>
        </div>
        <div class="mb-3">
            <label for="password2" class="form-label">Ulangi password</label>
            <input type="password" id="password2" name="password2" class="form-control<?= kelasError($err, 'password2') ?>" autocomplete="new-password" required>
            <?= pesanError($err, 'password2') ?>
        </div>
        <button type="submit" class="btn btn-primary w-100">Daftar</button>
    </form>
    <p class="text-center mt-3 mb-0">Sudah punya akun? <a href="login.php">Login</a></p>
</div>
<?php require 'includes/footer.php'; ?>
