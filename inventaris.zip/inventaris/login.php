<?php
require_once 'config/koneksi.php';
require_once 'includes/auth.php';
require_once 'includes/crud.php';

if (sudahLogin()) {
    redirect('dashboard.php');
}

$error = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = input('username');
    $password = input('password', false);

    if (!csrfValid()) {
        $error = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
    } elseif ($username === '' || $password === '') {
        $error = 'Username dan password wajib diisi.';
    } else {
        $user = cariUser($db, $username);
        if ($user && password_verify($password, $user['password'])) {
            loginUser($user);
            redirect('dashboard.php');
        }
        $error = 'Username atau password salah.';
    }
}

$judul = 'Login';
require 'includes/header.php';
?>
<div class="panel panel-sempit">
    <?php if ($error !== ''): ?>
        <div class="pesan pesan-error"><?= e($error) ?></div>
    <?php endif; ?>
    <form method="post" novalidate>
        <?= csrfField() ?>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" id="username" name="username" class="form-control" value="<?= e($username) ?>" autocomplete="username" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" id="password" name="password" class="form-control" autocomplete="current-password" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Masuk</button>
    </form>
    <p class="text-center mt-3 mb-0">Belum punya akun? <a href="register.php">Registrasi</a></p>
</div>
<?php require 'includes/footer.php'; ?>
