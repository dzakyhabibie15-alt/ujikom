<?php
require_once 'includes/auth.php';

// Logout hanya lewat POST + token CSRF agar tidak bisa dipicu dari link luar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrfValid()) {
    logoutUser();
    session_start();
    setFlash('sukses', 'Anda sudah logout.');
}
redirect('login.php');
